const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
//-----------------------ROUTES-------------------------


router.get('/home', userController.viewHome);
router.get('/registration', userController.viewReg);
router.get('/login', userController.viewLogin);
router.post('/registration', userController.adduser);
router.post('/login', userController.login);

//admin
router.get('/viewAdmin', userController.viewAdmin);
router.get('/addExercise', userController.viewaddExercise);
router.get('/addProgramm', userController.viewaddProgramm);
router.get('/viewAllusers', userController.viewAllusers);
router.post('/addExercise', userController.addExercise);
router.post('/addProgramm', userController.addProgramm);

//global
router.get('/changeProfile', userController.changeProfile);
router.post('/postchangeProfile', userController.postchangeProfile);
router.get('/changeAccess', userController.changeAccess);
router.post('/postchangeAccess', userController.postchangeAccess);
//Pro
router.get('/viewPro', userController.viewPro);

//intermidiate
router.get('/viewIntermidiate', userController.viewIntermidiate);

//begginer
router.get('/viewBegginer', userController.viewBegginer);

//Guest
router.get('/viewGuest', userController.viewGuest);


module.exports = router;