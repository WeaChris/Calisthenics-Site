const routes = require('./server/routes/user');
const express = require('express');
const mysql = require('mysql');
const bodyParser =require("body-parser");
const exphbs = require("express-handlebars");


const app = express();

app.engine('hbs', exphbs({ extname: '.hbs' }));
app.set('view engine', 'hbs');


const port = process.env.PORT || 5000

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static('public'));

//create connection with mysql
const database = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'progdiadiktio'
});
//Connect
database.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('My sql connected...');
});

app.use('/', routes);

app.listen(port, ()=> console.log(`Listen on port ${port}`));