const mysql = require('mysql');
var currentUser = 0;

//create connection with mysql
const pool = mysql.createPool({
    connectionLimit: 100,
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'progdiadiktio'
});


//VIEW HOME PAGE
exports.viewHome = (req, res) => {
    res.render('home');
}

exports.viewReg = (req, res) => {
    res.render('registration');
}

exports.viewaddExercise = (req, res) => {
    res.render('addExercise');
}

exports.viewaddProgramm = (req, res) => {
    res.render('addProgramm');
}

exports.viewLogin = (req, res) => {
    res.render('login');
}



exports.adduser = (req, res) => {
    const { name, surname, email, password } = req.body;
    const status = 5;
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('INSERT INTO user SET ID = ? , name = ? , surname= ? , email= ? , password = ? , status = ?', ["", name, surname, email, password, status], (err, rows) => {
            connection.release();
            if (!err) {
                res.render('home');


            } else {
                console.log(err);
            }

        });
    });
}

exports.login = (req, res) => {

    const { email, password } = req.body;

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('SELECT ID,email,password,status, name, surname FROM user WHERE email= ? AND password = ?;', [email, password], (err, rows) => {
            connection.release();
            if (!err) {
                if (rows[0].email == email && rows[0].password == password) {

                    res.render('athletes/' + [rows[0].status], { rows });
                    currentUser = rows[0].ID;
                    console.log(currentUser);
                }

            } else {
                console.log(err);
            }

        });
    });
}

exports.viewAdmin = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('SELECT * FROM full_body_programm', (err, rows) => {

            if (!err) {
                

                connection.query('SELECT * FROM exercise', (err, rowsE) => {

                    if (!err) {
                        console.log(rowsE);
                        res.render('viewAdmin', { rows, rowsE });
                    } else {
                        console.log(err);
                    }
                });

            } else {
                console.log(err);
            }
        });


    });

}

exports.viewIntermidiate = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT name, surname, status FROM user WHERE ID=?', [currentUser], (err, name) => {
            if (!err) {
                console.log(currentUser);
                console.log(name);
                connection.query('SELECT name, progression, exercise_1, exercise_2, exercise_3, exercise_4, exercise_5 FROM full_body_programm WHERE progression = ? OR progression = ?', ['intermidiate', 'begginer'], (err, programms) => {
                    if (!err) {

                        connection.query('SELECT * FROM exercise', (err, exercises) => {
                            if (!err) {

                                connection.query('SELECT name FROM status WHERE ID=?', [name[0].status], (err, statusInfo) => {
                                    if (!err) {
                                        res.render('viewIntermidiate', { name, programms, exercises ,statusInfo});
                                    } else {
                                        console.log(err);
                                    }
                                });

                                
                            } else {
                                console.log(err);
                            }

                        });


                    } else {
                        console.log(err);
                    }

                });

            } else {
                console.log(err);
            }

        });
    });
}


exports.viewPro = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT name, surname, status FROM user WHERE ID=?', [currentUser], (err, name) => {
            if (!err) {
                console.log(currentUser);
                console.log(name);
                connection.query('SELECT name, progression, exercise_1, exercise_2, exercise_3, exercise_4, exercise_5 FROM full_body_programm WHERE progression = ? OR progression = ? OR progression = ?', ['intermidiate', 'begginer', 'pro'], (err, programms) => {
                    if (!err) {

                        connection.query('SELECT * FROM exercise', (err, exercises) => {
                            if (!err) {

                                connection.query('SELECT name FROM status WHERE ID=?', [name[0].status], (err, statusInfo) => {
                                    if (!err) {
                                        res.render('viewPro', { name, programms, exercises ,statusInfo});
                                    } else {
                                        console.log(err);
                                    }
                                });

                                
                            } else {
                                console.log(err);
                            }

                        });


                    } else {
                        console.log(err);
                    }

                });

            } else {
                console.log(err);
            }

        });
    });
}


exports.viewBegginer = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT name, surname status FROM user WHERE ID=?', [currentUser], (err, name) => {
            if (!err) {
                console.log(currentUser);
                console.log(name);
                connection.query('SELECT name, progression, exercise_1, exercise_2, exercise_3, exercise_4, exercise_5 FROM full_body_programm WHERE progression = ?', ['begginer'], (err, programms) => {
                    if (!err) {

                        connection.query('SELECT * FROM exercise', (err, exercises) => {
                            if (!err) {
                                connection.query('SELECT name FROM status WHERE ID=?', [name[0].status], (err, statusInfo) => {
                                    if (!err) {
                                        res.render('viewBegginer', { name, programms, exercises ,statusInfo});
                                    } else {
                                        console.log(err);
                                    }
                                });
                                
                            } else {
                                console.log(err);
                            }

                        });


                    } else {
                        console.log(err);
                    }

                });

            } else {
                console.log(err);
            }

        });
    });
}

exports.viewGuest = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT name, surname ,status FROM user WHERE ID=?', [currentUser], (err, name) => {
            if (!err) {
                console.log(currentUser);
                console.log(name);

                connection.query('SELECT * FROM exercise', (err, exercises) => {
                    if (!err) {

                        connection.query('SELECT name FROM status WHERE ID=?', [name[0].status], (err, statusInfo) => {
                            if (!err) {
                                res.render('viewGuest', { name, exercises, statusInfo });
                            } else {
                                console.log(err);
                            }
                        });
                    } else {
                        console.log(err);
                    }
            });

            } else {
                console.log(err);
            }
        });
    });
}
exports.addExercise = (req, res) => {

    const { name, main_muscle, way, instructions } = req.body;

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('INSERT INTO exercise SET ID=? , name= ? , main_muscle=? , way= ? , instructions = ? ', [null, name, main_muscle, way, instructions], (err) => {
            connection.release();
            if (!err) {

                connection.query('SELECT * FROM full_body_programm', (err, rows) => {

                    if (!err) {
                        console.log(rows);

                        connection.query('SELECT * FROM exercise', (err, rowsE) => {

                            if (!err) {
                                console.log(rowsE);
                                res.render('viewAdmin', { rows, rowsE });
                            } else {
                                console.log(err);
                            }
                        });

                    } else {
                        console.log(err);
                    }
                });

            } else {
                console.log(err);
            }

        });
    });
}
exports.addProgramm = (req, res) => {

    const { name, progression, exercise_1, exercise_2, exercise_3, exercise_4, exercise_5 } = req.body;


    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('INSERT INTO exercise SET ID=? , name= ? , progression=? , exercise_1= ? , exercise_2 = ? , exercise_3 = ? , exercise_4 = ? , exercise_5 = ?', ['', name, progression, exercise_1, exercise_2, exercise_3, exercise_3, exercise_4, exercise_5], (err) => {
            connection.release();
            if (!err) {

                connection.query('SELECT * FROM full_body_programm', (err, rows) => {

                    if (!err) {
                        

                        connection.query('SELECT * FROM exercise', (err, rowsE) => {

                            if (!err) {
                                console.log(rowsE);
                                res.render('viewAdmin', { rows, rowsE });
                            } else {
                                console.log(err);
                            }
                        });

                    } else {
                        console.log(err);
                    }
                });

            } else {
                console.log(err);
            }

        });
    });
}

exports.viewAllusers = (req, res) => {

    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('SELECT * FROM user', (err, rows) => {
            res.render('viewAllusers', { rows });
        });

    });

}

exports.changeProfile = (req, res) => {
    res.render('changeProfile');
}

exports.postchangeProfile = (req, res) => {

    const { name, surname, email, password ,status} = req.body;
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }

        connection.query('UPDATE user SET name = ? , surname= ? , email= ? , password = ? , status = ? WHERE ID= ?', [name, surname, email, password, status, currentUser], (err) => {
            connection.query('SELECT name, surname FROM user WHERE ID=?', [currentUser], (err, name) => {
                if (!err) {
                    console.log(currentUser);
                    console.log(name);
                    connection.query('SELECT name, progression, exercise_1, exercise_2, exercise_3, exercise_4, exercise_5 FROM full_body_programm WHERE progression = ? OR progression = ?', ['intermidiate', 'begginer'], (err, programms) => {
                        if (!err) {

                            connection.query('SELECT * FROM exercise', (err, exercises) => {
                                if (!err) {

                                    res.render('viewIntermidiate', { name, programms, exercises });
                                } else {
                                    console.log(err);
                                }

                            });


                        } else {
                            console.log(err);
                        }

                    });

                } else {
                    console.log(err);
                }

            });
        });

    });

}


exports.changeAccess = (req, res) => {
    pool.getConnection((err, connection) => {
        if (err) {
            console.log(err);
        }

        connection.query('SELECT * FROM status', (err, statusAll) => {
            if (!err) {
                
                res.render('changeAccess', {statusAll});


            }else{
                console.log(err);
            }
        });


    });
}
exports.postchangeAccess = (req, res) => {
    
    const status = req.body.option;
    console.log(status);
    pool.getConnection((err, connection) => {
        if (err) {
            console.log(err);
        }

        connection.query('UPDATE user SET status= ? WHERE user.ID=?',[status, currentUser], (err) => {
            if (!err) {
                
                if(status==2){
                    this.viewPro(req, res);
                }else if(status==3){
                    this.viewIntermidiate(req, res);
                }else if(status==4){
                    this.viewBegginer(req, res);
                }else if(status==5){
                    this.viewGuest(req, res);
                }


            }else{
                console.log(err);
            }
        });


    });
}

exports.viewEditUser = (req, res) => {
    const id=req.params.ID;
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT * FROM user WHERE ID=?', [id], (err, rows) => {
            connection.release();
            if (!err) {
                res.render('editUser', {rows});
            } else {
                console.log(err);
            }

        });
    });
    
}

exports.editUser = (req,res)=>{
    const { name, surname, email, password ,status} = req.body;
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        console.log(req.params.ID);
        connection.query('UPDATE user SET name = ? , surname= ? , email= ? , password = ? , status = ? WHERE ID=?', [name, surname, email, password, status, req.params.ID], (err) => {
            connection.release();
            if (!err) {
                
                console.log('USER UPDATED');
                


            } else {
                console.log(err);
            }

        });
    });

}




exports.viewDeleteUser = (req, res) => {
    const id=req.params.ID;
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        connection.query('SELECT * FROM user WHERE ID=?', [id], (err, rows) => {
            connection.release();
            if (!err) {
                res.render('deleteUser', {rows});
            } else {
                console.log(err);
            }

        });
    });
    
}

exports.deleteUser = (req,res)=>{
    
    pool.getConnection((err, connection) => {
        if (err) {
            throw err;
        }
        console.log(req.params.ID);
        connection.query('DELETE FROM user WHERE ID=?', [req.params.ID], (err) => {
            connection.release();
            if (!err) {
                
                console.log('USER DELETED');
                
            } else {
                console.log(err);
            }

        });
    });

}